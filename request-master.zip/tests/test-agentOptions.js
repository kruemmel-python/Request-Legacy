'use strict'
/* test-agentOptions.js disabled (see instructions) */
