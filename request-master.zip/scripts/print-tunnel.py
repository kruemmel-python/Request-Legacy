from pathlib import Path

print(Path('tests/test-tunnel.js').read_text())
